package com.example.apiCotemigGamers.model;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;

public class Transacao implements Serializable {
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    public int idTransacao_Carteira;
    public int Usuario_idUsuario;
    public int idCarteira;
    public double valor;
    public String dataPagaemnto;
    public int Produto_idProduto;

    public int getIdTransacao_Carteira() {
        return idTransacao_Carteira;
    }

    public void setIdTransacao_Carteira(int idTransacao_Carteira) {
        this.idTransacao_Carteira = idTransacao_Carteira;
    }

    public int getUsuario_idUsuario() {
        return Usuario_idUsuario;
    }

    public void setUsuario_idUsuario(int usuario_idUsuario) {
        Usuario_idUsuario = usuario_idUsuario;
    }

    public int getIdCarteira() {
        return idCarteira;
    }

    public void setIdCarteira(int idCarteira) {
        this.idCarteira = idCarteira;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getDataPagaemnto() {
        return dataPagaemnto;
    }

    public void setDataPagaemnto(String dataPagaemnto) {
        this.dataPagaemnto = dataPagaemnto;
    }

    public int getProduto_idProduto() {
        return Produto_idProduto;
    }

    public void setProduto_idProduto(int produto_idProduto) {
        Produto_idProduto = produto_idProduto;
    }
}
