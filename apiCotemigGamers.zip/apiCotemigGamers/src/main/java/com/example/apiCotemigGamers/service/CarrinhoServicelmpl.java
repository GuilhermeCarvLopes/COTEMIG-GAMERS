package com.example.apiCotemigGamers.service;

import com.example.apiCotemigGamers.model.Carrinho;
import com.example.apiCotemigGamers.model.Categoria;
import com.example.apiCotemigGamers.repository.CategoriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service("CarrinhoService")
public class CarrinhoServicelmpl implements CarrinhoService {


    @Override
    public Optional<Carrinho> getCarrinhoById(Integer id) {
        return Optional.empty();
    }

    @Override
    public List<Carrinho> getAllCarrinhos() {
        return null;
    }

    @Override
    public void deleteAllCarrinhos() {

    }

    @Override
    public void deleteCarrinhoById(Integer id) {

    }

    @Override
    public void updateCarrinhoById(Integer id, Carrinho carrinho) {

    }

    @Override
    public void updateCarrinho(Carrinho carrinho) {

    }

    @Override
    public void insertCarrinho(Carrinho carrinho) {

    }
}
