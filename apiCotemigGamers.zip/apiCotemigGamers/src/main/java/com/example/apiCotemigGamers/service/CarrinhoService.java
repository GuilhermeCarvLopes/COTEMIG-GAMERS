package com.example.apiCotemigGamers.service;

import com.example.apiCotemigGamers.model.Biblioteca;
import com.example.apiCotemigGamers.model.Carrinho;

import java.util.List;
import java.util.Optional;

public interface CarrinhoService {
    Optional<Carrinho> getCarrinhoById(Integer id);
    List<Carrinho> getAllCarrinhos();
    void deleteAllCarrinhos();
    void deleteCarrinhoById(Integer id);
    void updateCarrinhoById(Integer id, Carrinho carrinho);
    void updateCarrinho(Carrinho carrinho);
    void insertCarrinho(Carrinho carrinho);
}

