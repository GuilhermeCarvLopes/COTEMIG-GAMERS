package com.example.apiCotemigGamers.repository;

import com.example.apiCotemigGamers.model.Carrinho;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository("CarrinhoRepository")
public interface CarrinhoRepository extends JpaRepository<Carrinho, Integer> {
}
