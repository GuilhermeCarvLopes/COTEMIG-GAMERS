package com.example.apiCotemigGamers.controller;

import com.example.apiCotemigGamers.model.Biblioteca;
import com.example.apiCotemigGamers.model.Carrinho;
import com.example.apiCotemigGamers.service.BibliotecaService;
import com.example.apiCotemigGamers.service.CarrinhoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class CarrinhoController {

    @Autowired
    private CarrinhoService carrinhoService;

    @RequestMapping(value = "/rest/getAll", method = RequestMethod.GET)
    public List<Carrinho> getBibliotecas() {
        return carrinhoService.getAllCarrinhos();
    }

    @RequestMapping(value = "/rest/get/{id}", method = RequestMethod.GET)
    public Optional<Carrinho> getBiblioteca(@PathVariable("id") Integer id) {
        return carrinhoService.getCarrinhoById(id);
    }

    @RequestMapping(value = "/rest/deleteAll", method = RequestMethod.DELETE)
    public void deleteBibliotecas() {
        carrinhoService.deleteAllCarrinhos();
    }

    @RequestMapping(value = "/rest/delete/{id}", method = RequestMethod.DELETE)
    public void deleteBiblioteca(@PathVariable("id") Integer id) {
        carrinhoService.deleteCarrinhoById(id);
    }

    @RequestMapping(value = "/rest/update/{id}", method = RequestMethod.POST)
    public void updateBiblioteca(@RequestBody Carrinho carrinho, @PathVariable("id") Integer id) {
        carrinhoService.updateCarrinhoById(id, carrinho);
    }

    @RequestMapping(value = "/rest/insert", method = RequestMethod.POST)
    public void insertBiblioteca(@RequestBody Carrinho carrinho) {
        carrinhoService.insertCarrinho(carrinho);
    }

}
