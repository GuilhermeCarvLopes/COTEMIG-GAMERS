package com.example.apiCotemigGamers.repository;

import com.example.apiCotemigGamers.model.TransacaoCarteira;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository("transacaoCartRepository")
public interface TransacaoCarteiraRepository extends JpaRepository<TransacaoCarteira, Integer> {
}
