package com.example.apiCotemigGamers.service;


import com.example.apiCotemigGamers.model.Transacao;
import com.example.apiCotemigGamers.repository.TransacaoCarteiraRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service("transacaoCarteiraService")
public class TransacaoServicelmpl implements TransacaoService {

    @Autowired
    TransacaoCarteiraRepository transacaoCarteiraRepository;

    @Override
    public Optional<Transacao> getTransacaoById(Integer id) {
        return transacaoCarteiraRepository.findById(id);
    }

    @Override
    public List<Transacao> getAllTransacao() {
        return transacaoCarteiraRepository.findAll();
    }

    @Override
    public void deleteAllTransacao() {
        transacaoCarteiraRepository.deleteAll();
    }

    @Override
    public void deleteTransacaoById(Integer id) {
        transacaoCarteiraRepository.deleteById(id);
    }

    @Override
    public void updateTransacaoById(Integer id, Transacao transacao) {
        Optional<Transacao> getTransacao = getTransacaoById(id);
        getTransacao.get().setDataPagaemnto(transacao.getDataPagaemnto());
        transacaoCarteiraRepository.save(transacao);
    }

    @Override
    public void updateTransacao(Transacao transacao) {
        transacaoCarteiraRepository.save(transacao);
    }

    @Override
    public void insertTransacao(Transacao transacao) {
        transacaoCarteiraRepository.save(transacao);
    }

}
