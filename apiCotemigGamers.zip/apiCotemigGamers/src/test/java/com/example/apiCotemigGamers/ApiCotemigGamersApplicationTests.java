package com.example.apiCotemigGamers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiCotemigGamersApplicationTests {

	@Test
	void contextLoads() {
	}

}
