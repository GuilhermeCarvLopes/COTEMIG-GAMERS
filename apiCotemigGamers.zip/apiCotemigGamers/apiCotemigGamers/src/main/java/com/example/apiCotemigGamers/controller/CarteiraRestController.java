package com.example.apiCotemigGamers.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.apiCotemigGamers.model.Carteira;
import com.example.apiCotemigGamers.service.CarteiraService;

import java.util.List;
import java.util.Optional;

@RestController
public class CarteiraRestController {

    @Autowired
    private CarteiraService carteiraService;

    @RequestMapping(value = "/rest/carteira/getAll", method = RequestMethod.GET)
    public List<Carteira> getCarteiras() {
        return carteiraService.getAllCarteiras();
    }

    @RequestMapping(value = "/rest/carteira/get/{id}", method = RequestMethod.GET)
    public Optional<Carteira> getCarteira(@PathVariable("id") Integer id) {
        return carteiraService.getCarteiraById(id);
    }

    @RequestMapping(value = "/rest/carteira/deleteAll", method = RequestMethod.DELETE)
    public void deleteCarteiras() {
        carteiraService.deleteAllCarteiras();
    }

    @RequestMapping(value = "/rest/carteira/delete/{id}", method = RequestMethod.DELETE)
    public void deleteCarteira(@PathVariable("id") Integer id) {
        carteiraService.deleteCarteiraById(id);
    }

    @RequestMapping(value = "/rest/carteira/update/{id}", method = RequestMethod.POST)
    public void updateCarteira(@RequestBody Carteira carteira, @PathVariable("id") Integer id) {
        carteiraService.updateCarteiraById(id, carteira);
    }

    @RequestMapping(value = "/rest/carteira/insert", method = RequestMethod.POST)
    public void insertCarteira(@RequestBody Carteira carteira) {
        carteiraService.insertCarteira(carteira);
    }
    
}
