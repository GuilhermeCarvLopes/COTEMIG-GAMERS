package com.example.apiCotemigGamers.repository;

import com.example.apiCotemigGamers.model.Carteira;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository("CarteiraRepository")
public interface CarteiraRepository extends JpaRepository<Carteira, Integer> {
}
