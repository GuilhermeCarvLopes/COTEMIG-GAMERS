package com.example.apiCotemigGamers.controller;

import com.example.apiCotemigGamers.model.TipoProduto;
import com.example.apiCotemigGamers.service.TipoProdutoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class TipoProdutoRestController {

    @Autowired
    private TipoProdutoService tipoProdService;

    @RequestMapping(value = "/rest/tipoproduto/getAll", method = RequestMethod.GET)
    public List<TipoProduto> getTiposProdutos() {
        return tipoProdService.getAllTiposProdutos();
    }

    @RequestMapping(value = "/rest/tipoproduto/get/{id}", method = RequestMethod.GET)
    public Optional<TipoProduto> getTipoProduto(@PathVariable("id") Integer id) {
        return tipoProdService.getTipoProdutoById(id);
    }

    @RequestMapping(value = "/rest/tipoproduto/deleteAll", method = RequestMethod.DELETE)
    public void deleteTiposProdutos() {
        tipoProdService.deleteAllTiposProdutos();
    }

    @RequestMapping(value = "/rest/tipoproduto/delete/{id}", method = RequestMethod.DELETE)
    public void deleteTipoProduto(@PathVariable("id") Integer id) {
        tipoProdService.deleteTipoProdutoById(id);
    }

    @RequestMapping(value = "/rest/tipoproduto/update/{id}", method = RequestMethod.POST)
    public void updateTipoProdutos(@RequestBody TipoProduto tipoProduto, @PathVariable("id") Integer id) {
        tipoProdService.updateTipoProdutoById(id, tipoProduto);
    }

    @RequestMapping(value = "/rest/tipoproduto/insert", method = RequestMethod.POST)
    public void insertTipoProduto(@RequestBody TipoProduto tipoProduto) {
        tipoProdService.insertTipoProduto(tipoProduto);
    }

}
