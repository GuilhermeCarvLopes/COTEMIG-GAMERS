USE `cotemigGamer`;

SHOW CREATE TABLE BIBLIOTECA;
/* 'BIBLIOTECA', 
'CREATE TABLE `BIBLIOTECA` (\n  
			`USUARIO_idUSUARIO` int(11) NOT NULL,\n  
            `PRODUTO_idPRODUTO` int(11) NOT NULL,\n  
            `DATA` datetime NOT NULL,\n  
            PRIMARY KEY (`USUARIO_idUSUARIO`,`PRODUTO_idPRODUTO`),\n  
            KEY `fk_USUARIO_has_PRODUTO_PRODUTO1_idx` (`PRODUTO_idPRODUTO`),\n  
            KEY `fk_USUARIO_has_PRODUTO_USUARIO_idx` (`USUARIO_idUSUARIO`),\n  
            CONSTRAINT `fk_USUARIO_has_PRODUTO_PRODUTO1` FOREIGN KEY (`PRODUTO_idPRODUTO`) REFERENCES `produto` (`idPRODUTO`),\n  
            CONSTRAINT `fk_USUARIO_has_PRODUTO_USUARIO` FOREIGN KEY (`USUARIO_idUSUARIO`) REFERENCES `usuario` (`idUSUARIO`)\n
) ENGINE=InnoDB DEFAULT CHARSET=utf8' */

SHOW CREATE TABLE CARRINHO;
/* 'CARRINHO', 
'CREATE TABLE `CARRINHO` (\n  
			`idCARRINHO` int(11) NOT NULL AUTO_INCREMENT,\n  
            `USUARIO_idUSUARIO` int(11) NOT NULL,\n  
            `PRODUTO_idPRODUTO` int(11) NOT NULL,\n  
            `DATA` datetime NOT NULL,\n  
            PRIMARY KEY (`idCARRINHO`),\n  
            KEY `fk_CARRINHO_USUARIO1_idx` (`USUARIO_idUSUARIO`),\n  
            KEY `fk_CARRINHO_PRODUTO1_idx` (`PRODUTO_idPRODUTO`),\n  
            CONSTRAINT `fk_CARRINHO_PRODUTO1` FOREIGN KEY (`PRODUTO_idPRODUTO`) REFERENCES `produto` (`idPRODUTO`),\n  
            CONSTRAINT `fk_CARRINHO_USUARIO1` FOREIGN KEY (`USUARIO_idUSUARIO`) REFERENCES `usuario` (`idUSUARIO`)\n
) ENGINE=InnoDB DEFAULT CHARSET=utf8' */

SHOW CREATE TABLE CATEGORIA;
/* 'CATEGORIA', 
'CREATE TABLE `categoria` (\n
			`idCATEGORIA` int(11) NOT NULL AUTO_INCREMENT,\n  
            `NOME` varchar(45) NOT NULL,\n  
            PRIMARY KEY (`idCATEGORIA`)\n
) ENGINE=InnoDB DEFAULT CHARSET=utf8' */

SHOW CREATE TABLE CATEGORIA_PRODUTO;
/* 'CATEGORIA_PRODUTO', 
'CREATE TABLE `categoria_produto` (\n
			`IDCATEGORIA` int(11) NOT NULL,\n  
            `IDPRODUTO` int(11) NOT NULL,\n  
            PRIMARY KEY (`IDCATEGORIA`,`IDPRODUTO`),\n  
            KEY `fk_CATEGORIA_has_PRODUTO_PRODUTO1_idx` (`IDPRODUTO`),\n  
            KEY `fk_CATEGORIA_has_PRODUTO_CATEGORIA1_idx` (`IDCATEGORIA`),\n  
            CONSTRAINT `fk_CATEGORIA_has_PRODUTO_CATEGORIA1` FOREIGN KEY (`IDCATEGORIA`) REFERENCES `categoria` (`idCATEGORIA`),\n  
            CONSTRAINT `fk_CATEGORIA_has_PRODUTO_PRODUTO1` FOREIGN KEY (`IDPRODUTO`) REFERENCES `produto` (`idPRODUTO`)\n
) ENGINE=InnoDB DEFAULT CHARSET=utf8' */

SHOW CREATE TABLE EMPRESA;
/* 'EMPRESA', 
'CREATE TABLE `empresa` (\n  
			`idEMPRESA` int(11) NOT NULL AUTO_INCREMENT,\n  
            `NOMEFANTASIA` varchar(45) NOT NULL,\n  
            `RAZAOSOCIAL` varchar(45) NOT NULL,\n  
            `CNPJ` varchar(45) NOT NULL,\n  
            `EMAIL` varchar(45) NOT NULL,\n  
            `TELEFONE` varchar(45) NOT NULL,\n  
            `FOTO` varchar(45) NOT NULL,\n  
            `SENHA` varchar(45) NOT NULL,\n  
            PRIMARY KEY (`idEMPRESA`)\n
) ENGINE=InnoDB DEFAULT CHARSET=utf8' */

SHOW CREATE TABLE PRODUTO;
/* 'PRODUTO', 
'CREATE TABLE `produto` (\n  
			`idPRODUTO` int(11) NOT NULL AUTO_INCREMENT,\n  
            `NOME` varchar(45) NOT NULL,\n  
            `DESCRICAO` varchar(45) NOT NULL,\n  
            `VALOR` varchar(45) NOT NULL,\n  
            `IDEMPRESA` int(11) NOT NULL,\n  
            `IDTIPOPRODUTO` int(11) NOT NULL,\n  
            `FOTO` varchar(200) NOT NULL,\n  
            PRIMARY KEY (`idPRODUTO`),\n  
            KEY `fk_PRODUTO_EMPRESA1_idx` (`IDEMPRESA`),\n  
            KEY `fk_PRODUTO_TIPOPRODUTO1_idx` (`IDTIPOPRODUTO`),\n  
            CONSTRAINT `fk_PRODUTO_EMPRESA1` FOREIGN KEY (`IDEMPRESA`) REFERENCES `empresa` (`idEMPRESA`),\n  
            CONSTRAINT `fk_PRODUTO_TIPOPRODUTO1` FOREIGN KEY (`IDTIPOPRODUTO`) REFERENCES `tipoproduto` (`idTIPOPRODUTO`)\n
) ENGINE=InnoDB DEFAULT CHARSET=utf8' */

SHOW CREATE TABLE TIPOPRODUTO;
/* 'TIPOPRODUTO', 
'CREATE TABLE `tipoproduto` (\n  
			`idTIPOPRODUTO` int(11) NOT NULL AUTO_INCREMENT,\n  
            `NOME` varchar(45) NOT NULL,\n  
            PRIMARY KEY (`idTIPOPRODUTO`)\n
) ENGINE=InnoDB DEFAULT CHARSET=utf8' */

SHOW CREATE TABLE TRANSACAO_CARTEIRA;
/* 'TRANSACAO_CARTEIRA', 
'CREATE TABLE `transacao_carteira` (\n  
			`idTRANSACAO_CARTEIRA` int(11) NOT NULL AUTO_INCREMENT,\n  
            `USUARIO_idUSUARIO` int(11) NOT NULL,\n  
            `SALDO` varchar(45) NOT NULL,\n  TROCAR PELA COLUNA DOUBLE VALOR
            `DATAPAGAMENTO` datetime NOT NULL,\n  
            `PRODUTO_idPRODUTO` int(11) NOT NULL,\n  
            PRIMARY KEY (`idTRANSACAO_CARTEIRA`),\n  
            KEY `fk_TRANSACAO_CARTEIRA_USUARIO1_idx` (`USUARIO_idUSUARIO`),\n  
            KEY `fk_TRANSACAO_CARTEIRA_PRODUTO1_idx` (`PRODUTO_idPRODUTO`),\n  
            CONSTRAINT `fk_TRANSACAO_CARTEIRA_PRODUTO1` FOREIGN KEY (`PRODUTO_idPRODUTO`) REFERENCES `produto` (`idPRODUTO`),\n  
            CONSTRAINT `fk_TRANSACAO_CARTEIRA_USUARIO1` FOREIGN KEY (`USUARIO_idUSUARIO`) REFERENCES `usuario` (`idUSUARIO`)\n
) ENGINE=InnoDB DEFAULT CHARSET=utf8' */

SHOW CREATE TABLE USUARIO;
/* 'USUARIO', 
'CREATE TABLE `usuario` (\n  
			`idUSUARIO` int(11) NOT NULL AUTO_INCREMENT,\n  
            `NOME` varchar(45) NOT NULL,\n  
            `DATANASCIMENTO` varchar(45) NOT NULL,\n  
            `USERNAME` varchar(45) NOT NULL,\n  RETIRAR
            `CPF` varchar(45) NOT NULL,\n  
            `EMAIL` varchar(45) NOT NULL,\n  
            `SENHA` varchar(45) NOT NULL,\n  
            `TELEFONE` varchar(45) NOT NULL,\n  
            `FOTO` varchar(45) NOT NULL,\n  
            PRIMARY KEY (`idUSUARIO`)\n
) ENGINE=InnoDB DEFAULT CHARSET=utf8' */



